﻿English version:====================================
You will need this tool to properly extract the FSMOD.zip file.
Usage: fully extract this zip file, and then drag and drop the FSMOD.zip into the extract.bat file.

by Forsakensilver

