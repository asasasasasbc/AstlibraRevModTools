cd %~dp0
"%~dp07za.exe" x "%~1" -mcp=54936
pause